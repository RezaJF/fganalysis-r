# fganalysis R Package

## Overview

The `fganalysis` is an R package designed for common analyses performed in FinnGen. It provides functions for data processing, summarization, and visualization of lab measurements and drug purchases to study drug response.

## Installation

To use this package, you can install it from a local source. First, ensure you have the `devtools` package installed in R.

```R
# If devtools is not installed, run this line:
# install.packages("devtools")

# Set MAKEFLAGS for faster compilation if installing from source
Sys.setenv(MAKEFLAGS = "-j4")

# Install the package from its local directory
devtools::install("path/to/fganalysis-r")
```

Once installed, load the package into your R session:

```R
library(fganalysis)
```

## Data Access

The package accesses data through a centralized connection object. The connection is configured via a JSON file, which specifies the paths to different datasets.

### Configuration

The `connect_fgdata()` function reads a JSON configuration file to set up data sources. A sample configuration file `config/db_config.json` looks like this:

```json
{
    "pheno": {
        "path": "/path/to/finngen_R13_service_sector_detailed_longitudinal_1.0.parquet",
        "type": "parquet-hive"
    },
    "labs": {
        "path": "/path/to/finngen_R13_kanta_lab_1.0.parquet",
        "type": "parquet"
    },
    "minimum": {
        "path": "/path/to/finngen_R13_minimum_extended_1.0.parquet",
        "type": "parquet"
    },
    "cov_pheno": {
        "path": "/path/to/R13_COV_PHENO_V0.parquet",
        "type": "parquet"
    }
}
```

The package uses `duckdb` to query data stored in the `parquet` format. The connection object returned by `connect_fgdata` contains lazy-loaded `dplyr` tables (`tbl` objects), meaning the data is only loaded into memory when you explicitly perform a query.

The main data tables are:
- **`pheno`**: Longitudinal data from service sector records, including drug purchases.
- **`labs`**: Laboratory measurements from KANTA.
- **`minimum`**: Minimum phenotype data for individuals.
- **`cov_pheno`**: Covariate phenotype data.

### Connecting to Data

To establish a connection, pass the path to your configuration file to `connect_fgdata`:

```R
# The path can be relative or absolute
# In the FinnGen Sandbox, a pre-configured file is available
conn <- connect_fgdata("/finngen/shared_nfs/finngen/code/drugResponsePackage/config/db_config_sb.json")

# Or using a local config file
conn <- connect_fgdata("config/db_config.json")

# The returned object has attributes that are lazy loaded data frames of different phenotype data.
# You can start writing dplyr queries and e.g. joining to other tables. Nothing will happen before you actually request the data to be localized.
# Behind the scenes, a query engine optimizes the query and returns only the data matching your query.

# Query for individuals with ICD-10 code K51 (IBD)
ibd <- conn$pheno %>%
  filter((SOURCE == "INPAT" | SOURCE == "OUTPAT") & CODE1 == "K51" & ICDVER == "10") %>%
  group_by(FINNGENID) %>%
  summarize(n_diagnoses = n())

# Look at the number of rows
nrow(ibd)
# Returns NA because nothing has been queried before you ask for the data.
# Use function collect to execute the query and return results
ibd <- ibd %>% collect()
nrow(ibd)
# 258

# Get all labs with omopid 3007461
labs <- get_lab_measurements(conn$labs, c("3007461"))

# Get all drug purchases with ATC codes starting with L01B
dr <- get_drug_purchases(conn$pheno, c("L01B"))

# Create drug response data of lab changes after initiating a drug.
# First define time intervals from drug purchase to summarise lab values
# Here defining pre-measurements drug measurements to be 1 year before drug and
# after period to be 1 month to 1 year.
before_period <- c(-1, 0)
after_period <- c(1/12, 1)

# Create a dataframe containing LDL (omopid 3001308) response to first statin purchase
# (ATC codes starting with A10) for each finngen ID
resp <- create_drug_response(kanta = conn$labs,
                            phenos = conn$pheno,
                            lablist = c("3001308"),
                            druglist = c("A10"),
                            before_period = before_period,
                            after_period = after_period)

# Create plots and tables of the response
summarize_drug_response(resp, out_file_prefix = "3001308_A10_resp")
```

The returned `conn` object is a `fg_data_connection` object, and you can access the data tables as its attributes (e.g., `conn$pheno`, `conn$labs`).

## Available Functions

This package provides a suite of functions for drug response analysis.

### Data Connection
- **`connect_fgdata(path_to_conf)`**: Connects to the databases specified in the JSON configuration file and returns a `fg_data_connection` object.

### Data Retrieval
- **`get_lab_measurements(all_labs, lablist, ...)`**: Extracts lab measurements for specified OMOP concept IDs.
- **`get_drug_purchases(all_phenos, druglist, ...)`**: Extracts drug purchases for specified ATC codes. The matching is done on the beginning of the ATC code.
- **`get_first_purchase(all_phenos, druglist, ...)`**: A wrapper around `get_drug_purchases` to get only the first purchase event for each individual.

### Analysis
- **`create_drug_response(kanta, phenos, lablist, druglist, before_period, after_period, ...)`**: The main analysis function. It calculates the drug response based on lab value changes before and after the first drug purchase.
- **`generate_response_summary(lab_measurements, before_period, after_period, ...)`**: A helper function to calculate the summary statistics for the response (e.g., median value before and after treatment). Called by `create_drug_response`.

### Summarization and Output
- **`summarize_drug_response(drug_response, out_file_prefix)`**: Generates a PDF report with plots and tables summarizing the drug response analysis results.
- **`drug.response(...)`**: This is not a function to be called directly by the user, but rather the S3 object class that holds the results from `create_drug_response`. It's a list containing the response data, all lab measurements, all drug purchases, and the time periods used for the analysis.

## Example Workflow

Here is a complete example of how to use the package to analyze the effect of statins (ATC code `A10`) on LDL cholesterol levels (OMOP ID `3001308`).

```R
# 1. Load the package
library(fganalysis)

# 2. Connect to the data sources
#    (replace with the correct path to your config file)
conn <- connect_fgdata("config/db_config.json")

# The conn object contains lazy-loaded tables.
# You can use dplyr verbs on them. The query is executed only when you `collect()`.
# For example, count IBD diagnoses:
ibd_counts <- conn$pheno %>%
  filter((SOURCE == "INPAT" | SOURCE == "OUTPAT") & CODE1 == "K51" & ICDVER == "10") %>%
  group_by(FINNGENID) %>%
  summarise(n_diagnoses = n()) %>%
  collect()

print(head(ibd_counts))


# 3. Define parameters for drug response analysis
#    - Lab ID for LDL
#    - ATC code for statins
#    - Time windows for "before" and "after" measurements
lab_id <- c("3001308")
drug_codes <- c("A10")
before_window <- c(-1, 0)      # 1 year before to drug purchase
after_window <- c(1/12, 1)   # 1 month to 1 year after drug purchase

# 4. Run the drug response analysis
#    This function will:
#    - Get the relevant lab measurements and drug purchases.
#    - Find the first drug purchase for each individual.
#    - Calculate the difference in median lab values between the 'after' and 'before' periods.
response_data <- create_drug_response(
  kanta = conn$labs,
  phenos = conn$pheno,
  lablist = lab_id,
  druglist = drug_codes,
  before_period = before_window,
  after_period = after_window
)

# 5. Summarize the results
#    This will create a PDF file with plots and text files with summary tables.
summarize_drug_response(response_data, out_file_prefix = "statin_ldl_response_summary")
```

This will produce files like `statin_ldl_response_summary.pdf`, `statin_ldl_response_summary_responses_by_drug.txt`, etc., in your working directory.

## Development

Contributions and improvements are welcome.

### Running Tests

The package uses `testthat` for unit tests. To run the tests, use:

```R
devtools::test()
```

When adding new functionality, please add corresponding unit tests in the `tests/testthat/` directory.

## License

This package is licensed under the MIT License.
